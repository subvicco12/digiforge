# OWNER source overlay: REVIEW ONLY, DEPLOYMENT BLOCKED

This is NOT a standalone WordPress plugin or cumulative DigiForge release.
No installer, credential, wp-config.php, grant, database migration or activation hook is included.
Do not upload it through WordPress's plugin installer or extract it over a live site.
The three payload paths are relative to the existing digiforge plugin root.
Current committed payload/dependency drift refuses packaging; dirty checkout bytes
are never packaged. Source updates require independently reviewed new source pins.

ADD FirstPartyOwnerPolicy.php; REPLACE ShopAccessAuthority.php and ShopAccessPanel.php
only after separately authorized exact-scope installation and complete prerequisites.
The manifest lists existing dependency hashes for review; their code is NOT shipped here.
These reference hashes are NOT verified production hashes or complete installed dependency proof.

Prerequisites: fresh exact raw file preimages/hashes, proven prior absence of the new
file, complete boot/portal dependency comparison, compatible 1.0.103 architecture,
WordPress/PHP support, genuine user1 mailbox verification, privately verified account
and installation pin, protected configuration custody and legacy OWNER/DELEGATE review,
matched protected database/artifact checkpoint and authorized isolated restore evidence.
Masked/line-numbered connector output is not a rollback preimage.

Protected DIGIFORGE_FIRST_PARTY_OWNER has exactly version=integer1, account_sha256,
installation_sha256, genuine email_verified_at and bounded expires_at (at most365days).
Never generate these from profile email alone; do not export passwords, user_pass,
reset links, tokens or keys. Resetting a password invalidates an existing pin.
Preserve current-role/all15-capability checks, explicit enrollment, nonce/confirmation,
approval hash, revision/CAS/replay and immutable audits. No reads create grants.

Rollback requirements (NOT EXECUTED): freeze writes; retain exact two-file preimages
and protected authority/configuration state. Restore the coherent approved preimage set;
remove the added policy only if its prior absence is proven. Do not resurrect retired
signed OWNER authority or discard new audit/revocation history with a blind DB restore.
If grants/writes occurred, stop for separately reviewed history-preserving recovery.
No automatic rollback, retention, erasure or cleanup is provided.

STOP ALL ON; external lock ON; automation OFF; Finance operationally excluded;
Standard POD/Jewelry inactive; RELEASE HOLD / NO-GO. Architecture scopes are not activation.
No merge, deployment, password reset, protected configuration write, OWNER grant,
provider operation, publishing, order or payment is authorized by this package.
