# DigiForge bounded hosted synthetic pilot — approval package

Prepared 15 November 2026. **PLAN ONLY; NOT PROVISIONED OR EXECUTION AUTHORIZED.**

Source remains API PR1260 `200e6101bf8635453b2186be2f45ec87a5946465`. Core PR1264 `78e7f973455a3c89319be06f0907caf2103658a7` and companion PR1263 `4da802a1568b13bcf1bbca28eba009b8b6148ef1` are not changed. The prior exact-head source audit is https://github.com/subvicco12/digiforge/actions/runs/43687155980 . Its passing source tests do not certify hosted infrastructure or artifacts.

## Scope and selected minimum

Reuse the frozen Stage A target and existing private caller, without extending either runtime. A target alone cannot provide authenticated operator initiation; a public HTTP test proxy would expand the attack surface. The existing manual Cloudflare Workflow supplies management-plane initiation and requires one caller Worker and one caller SQLite object. A new witness or independently administered service is unnecessary for this limited platform pilot and would misleadingly imply recovery qualification. No real provider sender, credential, DigiForge integration or policy exception is involved.

This pilot qualifies the platform, private invocation and synthetic SQL/state faults only. It does NOT host the full checkpoint observer/final-sender from later PR1260 work. Its 24 fixed cases do not include a remote witness-outage or observer stale-proof case; those remain offline-verified and require a separately reviewed hosted runtime extension. Do not label local observer tests as hosted passes or expose a generic fault selector to fill that gap.

## Exact resources

| Resource | Name/class | Binding/quantity |
|---|---|---|
| Target Worker | `digiforge-dispatcher-qualification` | 1 Worker, 7 closed ESM modules |
| Target SQLite Durable Object | `DigiForgeQualificationState` | `DF_QUAL_STATE`, 1 namespace, one fixed object `digiforge-stage-a-singleton-v1` |
| Private caller Worker | `digiforge-stage-a-caller` | 1 Worker; `DF_STAGE_A` binds exactly to target |
| Caller SQLite Durable Object | `DigiForgeStageACallerState` | `DF_CALLER_STATE`, 1 namespace, one fixed object `digiforge-stage-a-caller-singleton-v1` |
| Manual Workflow | `digiforge-stage-a-manual` / `DigiForgeStageAManual` | `DF_MANUAL_WORKFLOW`, 1 definition, at most128 manually initiated control instances |

Total: **two Workers, two SQLite namespaces, two intended singleton objects, one Workflow definition**. Twenty-four successful ADVANCE_ONE instances normally complete the fixed sequence, plus separately initiated bounded receipt reads if needed. No DNS/custom domain/routes/workers.dev/previews, KV/D1/R2, queues, alarms, schedules, provider secrets or production bindings.

## Immutable preparation and disabled configuration

The package contains the two existing deterministic source bundles, not an executable deployment script. Their deployment directories are the only upload candidates; tests, offline adapters, comparator and other source files must not be uploaded as runtime modules.

- `pilot-target-200e6101-source.zip`: 663,971bytes, SHA256 `fd3c393be6d60a2845489869becfd78f698a42507b784a815ca90709bc33fc14`.
- `pilot-caller-200e6101-source.zip`: 644,091bytes, SHA256 `c728cc84e44f5a1c4b75605fd36e76d8c7e7c30daa99fe7ae1590636aba1d197`.
- Target build ID: `b0d29d9f7b362c420b5c56143315ebd1e0cde92d7f00fe4bdff3f46a9836ca1e`.
- Pinned CLI: Wrangler4.150.0; included npm integrity and transitive package lock. No runtime npm dependency. No install or CLI execution performed here.
- Target mode `DISABLED`, windows0. Caller mode `DISABLED`, windows0, approval digest all-zero. Both public HTTP implementations always503; `workers_dev:false`, `preview_urls:false`, routesempty, observabilityOFF, sourcemapsOFF.
- Runtime imports have a closed graph. Synthetic factory seals network APIs, failing closed if sealing is unavailable; no provider/sockets transport or caller URL/header/credential input. This is frozen-source confinement, not a network firewall against a Cloudflare administrator replacing code.
- A manifest/build ID is byte identity and configuration evidence, not hosted execution attestation. Read back deployment modules, route settings, binding identities and version IDs before considering an enabled window.

## Authenticated invocation and bounds

No public execution, reset, SQL or fault-injection endpoint. Only a separately approved authenticated Cloudflare management principal may create a manual instance. Endpoint: `POST /accounts/{approved_account_id}/workflows/digiforge-stage-a-manual/instances`. The existing `operator-plan.mjs` creates JSON **only**; it neither authenticates nor sends. An approval digest is a reviewed-plan binding, not a password and not evidence that the initiating principal is the DigiForge owner. Review exact principal/account and its effective grants independently.

The official API accepts Workers Scripts Write for initiation; this grant is broader than invocation alone. Supported narrower IAM/custom-role/resource restrictions and connector ability to submit the exact manual request are NOT verified. Read-only account access or accepted membership does not prove Write. No token is accessed, provisioned or embedded by this package; no GitHub inventory workflow runs.

| Limit | Enforced scope |
|---|---|
| Window | At most3600seconds; recommend one shared 60-minute approved UTC window |
| Cases | Fixed24, sequential; no caller-selected faults/reset |
| Target logical work | At most1000 operation/admission attempts per singleton/window |
| Caller control | At most1000 admissions,128 distinct requests,24 advance intents |
| Pacing | At most3 admissions/rolling60seconds on each side; each advance uses target status+qualify; operator waits at least61seconds AFTER completed advance |
| Session | At most10 slots,300seconds in synthetic state; operator request expires within120seconds |
| RPC/Workflow |20seconds per RPC;50second Workflow step; zero configured retries |
| Response/storage |1,048,576byte fixture response;10,000,000byte target SQLite ceiling plus1,000,000byte caller ceiling;64KiB caller journal |

These caps are not platform billing/total-request firewalls. Rejected API/platform requests, managed retention, PITR logs and control-plane traffic add usage. SQLite databaseSize does not measure billed rows, peak storage or Workflow state. Namespace restoration/replacement can rewind local budgets. No automatic cleanup, alarm, timer or background scheduler is installed.

## Automatic denial and UNKNOWN disposition

Unknown bindings/modes, production credentials, expired window/grant, wrong build/approval/instance, quota or storage exhaustion and unavailable egress seal deny. Caller preflight AND terminal receipt must match the exact frozen build. Failure/timeout/lost acknowledgement, restart with unresolved latch, malformed receipt or uncertain persistence leaves UNKNOWN and blocks new advances. No slot restoration, fresh intent retry, automatic rearm or inferred success from matching counts/time.

Receipt READ_RECEIPT/RECONCILE can recover only an already committed caller receipt, without target dispatch. Local receipt reads may remain available after the execution window with fresh authorized control requests and within their budgets; expiry denies new work, not necessarily local evidence access. Frozen target lacks intent-correlated lookup: if the target response is lost before caller receipt commits, UNKNOWN may be irreconcilable. Stop the pilot; do not rerun under a new operation ID. Actual Cloudflare restart/outage behavior remains untested.

## Hosted adversarial acceptance plan

Machine-readable matrix `hosted-adversarial-plan.json` distinguishes fixed hosted cases, caller acceptance probes, destructive recovery experiments requiring extra approval, and missing hosted capabilities. Every row starts HOSTED_NOT_EXECUTED. The fixed all_root_counterexample must return COUNTEREXAMPLE_REPRODUCED / RECOVERY_BLOCKED; this is a known failure of the desired security invariant, not a recovery PASS.

Start with ONE manual `atomic_commit` smoke invocation. Inspect exact minimized receipt, CPU, storage/SQL usage and no-egress behavior; stop on CPU/free-tier failure, unknown acknowledgement or mismatched deployment. Only after that evidence is reviewed may remaining fixed cases advance manually. A 10ms Free Worker/Workflow CPU limit may prevent this source running; do not upgrade automatically or weaken cases.

Do not perform actual hosted PITR, namespace replacement, Worker rollback, network policy change or endpoint removal during this first run. The existing cases model these in fixture state. Real destructive/recovery tests require separately enumerated resources, review and approval. Do not spoof a hosted witness outage by calling a storage-failure test.

## Logging and evidence

No console/debug/raw HTTP logging, live tail, Logpush, analytics bindings, customer payloads or credentials. Observability and source maps remain OFF. Platform management audit metadata and Workflow retention still exist; loggingOFF is not zero platform retention. Store minimized case IDs/statuses, approved build/version IDs, bounded resource counts, timestamps, CPU/SQL metrics and redacted error categories. Do not export headers, tokens, private keys, cookies, full control payloads or unrelated account/resource data. Retain case counterexamples and UNKNOWN faithfully. Receipt export requires bounded authenticated management reads, not a new public endpoint.

## Account entitlement and cost decision

Two authorized read-only metadata calls on15Nov2026: Workers account settings succeeded with `default_usage_model:standard`; subscriptions returned403 and requires Billing Read or Billing Write. Standard is NOT evidence of Workers Free enrollment or remaining allowance. Existing owner-supplied zero resources and account membership are historical inventory, not fresh balance/billing evidence. No resource inventory or role scan was repeated.

Current public documentation supports Workers Free, SQLite DOs and Workflows on Free. Published Workers/Workflows allowance100,000requests/day (shared), Free CPU10ms/invocation; Workflow3,000steps/day and1GB-month state. DO100,000requests/day,13,000GB-s/day,5million rows read/day,100,000rows written/day,5GB SQLite total. These are published general limits, NOT verified account grants/headroom. Workflow retained state and managed DO data may remain after the60minute window.

Expected normal run:24 manual Workflow instances/steps,24 caller DO RPCs,48 target RPCs/DO calls plus explicitly approved bounded receipt reads. Same-account service binding does not establish independence. Pessimistic two128MB objects kept active for3600seconds =921.6GB-s before other platform overhead, not a measured bill. Primary SQLite ceilings total11MB; SQL-row/CPU/Workflow-storage usage cannot be inferred from bytes or logical attempts and must be measured. Do not add quotas together as though accounts were independent.

**Estimated incremental service charge USD0 ONLY IF the intended account is confirmed on Workers Free, these products eligible and sufficient shared quota available. Current guarantee: UNVERIFIED/BLOCKED.** Paid Workers public minimumUSD5/month is not authorized. On Free quota exhaustion denies; on Paid included allotments are not an enforceable USD0 cap. Obtain non-secret Workers plan, SQLite/Workflows entitlement and current quota evidence via Billing Read or owner-provided plan screenshots. Do not request Billing Write merely for inspection, change account plan/spend controls, activate paid trials or probe writes. No exact invoice amount or billing-cap certification is asserted.

## Exact future provisioning sequence — not executed

1. Owner approves this immutable bundle and exact target account, intended operator, USD0-only restriction, resource names, retained-data policy and no-production scope. First resolve actual Free entitlement, product eligibility, quota headroom and write permissions; otherwise STOP.
2. Read exact name collisions and ownership. Abort if any name belongs to unrelated work. Approve the pinned CLI/dependency lock, clean extraction directory, account-specific disabled manifests and future authentication path separately. Never load `.env`, `.dev.vars`, secret values or generated Wrangler override configs from another project.
3. Provision target disabled by uploading only its7 reviewed modules and disabled manifest; migration `stage-a-synthetic-v1` creates SQLite class DigiForgeQualificationState and binds DF_QUAL_STATE. No other binding.
4. Provision caller disabled with its closed10-module graph; migration `stage-a-caller-v1` creates DigiForgeStageACallerState and DF_CALLER_STATE, DF_STAGE_A fixed target, and the single manual Workflow. No provider secrets, public endpoint, routes, previews, triggers or schedules. These operations are API writes and remain UNAUTHORIZED now.
5. Record returned script/deployment/namespace/Workflow IDs. Independently read back bytes, binding types, URL settings, no secrets/triggers and disabled status. Unknown or mismatch denies. Do not execute a test while still certifying provisioning.
6. Obtain separate approval of one rendered paired enabled configuration: correct synthetic modes only, frozen build, nonzero reviewed approval digest, exact UTC start/end<=3600seconds. No core STOP/lock changes. Enabling synthetic mode does not grant native DigiForge business execution.
7. Obtain separate approval of the exact first manual instance request (plan generated by existing operator-plan), authenticated principal and account. Start only atomic_commit. After measured result review, separately release remaining23 fixed advances; at least61seconds after each completed advance. No retry or unattended loop.
8. On denial, UNKNOWN, changed build, unexpected resource, provider egress, quota/CPU violation or expiry: cease initiation immediately and preserve evidence. Return modes to DISABLED through separately approved management changes. No new namespace or clock rollback to continue.

## Rollback and teardown — separate destructive approval

There is no production rollback: no DigiForge installation/database/config changed. Pilot rollback means deny/stop, retain UNKNOWN and dispose of this isolated namespace, never restore old spent authority.

1. Cease all new Workflow instance creation. For active instances, obtain specific approval to terminate each exact instance through `PATCH .../instances/{instance_id}/status`; statusGET must confirm terminal/drained state. Do not claim a successful management update cancels in-flight work immediately.
2. Disable caller and target configs; verify source bindings/no public URLs, active-instance status and denial. Expiry alone does not delete data or end potential billing.
3. Export only sanitized receipts/metrics, including all UNKNOWN/counterexample results. Record exact owned resource IDs. No deletion if ownership/retention approval is ambiguous.
4. Delete exact terminal Workflow instances where supported, then delete only Workflow `digiforge-stage-a-manual` through documented DELETE. Do not treat deletion as completed receipt evidence.
5. Prepare fresh-tag reviewed DO deletion migrations separately for the two disposable Workers with `deleted_classes:["DigiForgeStageACallerState"]` and `deleted_classes:["DigiForgeQualificationState"]`, removing corresponding export/binding and Workflow/service binding as appropriate. Applying deletion migrations destroys data. Never reuse original migration tags or delete shared namespaces.
6. After approved migration cleanup, delete only the two named owned Worker scripts using supported Worker DELETE. Deleting a Worker alone must not be assumed to remove every namespace, retained Workflow instance or charge. Verify exact script/Workflow/namespace absence and retained-data/usage disposition; archive sanitized cleanup receipts. If namespace deletion or retention is unresolved, keep cleanup status UNKNOWN, not complete. No automatic delete script included.

## Remaining approval gates

**READY_FOR_REVIEW:** immutable disabled target/caller bundles and offline evidence. **BLOCKED_BILLING_EVIDENCE:** account Free entitlement/headroom. **BLOCKED_OPERATOR:** exact reviewed management principal, accepted permissions and supported invocation. **OWNER_APPROVAL_REQUIRED:** resource creation, rendered window/config update, each bounded execution phase and destructive cleanup. **HOSTED_NOT_EXECUTED:** every hosted claim. **RECOVERY_BLOCKED/CREDENTIAL_CUSTODY_BLOCKED:** independent checkpoint/final sender, outside this pilot's certification scope. **LIVE_PROVIDER_NOT_AUTHORIZED:** all provider operations.

All-root rollback, old usable credential-copy bypass and historical signed observation after STOP remain explicit release blockers. No API method, successful local fixture, independent key string or same-account DO can resolve them. No synthetic epoch may be promoted into REGISTER/CLAIM/native authority.

## Official sources checked

- https://developers.cloudflare.com/workers/platform/pricing/
- https://developers.cloudflare.com/workers/platform/limits/
- https://developers.cloudflare.com/durable-objects/platform/pricing/
- https://developers.cloudflare.com/workflows/reference/pricing/
- https://developers.cloudflare.com/workflows/reference/limits/
- https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/rpc/
- https://developers.cloudflare.com/durable-objects/reference/durable-objects-migrations/
- Official connected OpenAPI: account subscriptions GET accepts Billing Read/Write; Worker upload/delete and Workflow initiation/cleanup require applicable write grants; listing/status accepts documented read grants. Accepted permission names do not establish granted scopes.

No Cloudflare resources, credential use, provider requests, source edits, production changes, inventory workflow activation, merge or policy activation. STOP ALL/external lock ON; automation OFF; RELEASE HOLD.
