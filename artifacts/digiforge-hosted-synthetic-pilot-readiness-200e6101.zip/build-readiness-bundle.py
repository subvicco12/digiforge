#!/usr/bin/env python3
"""Local deterministic packaging only: no CLI installation, account access or deployment."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

FILES = [
    'READINESS.md', 'build-readiness-bundle.py', 'entitlement-evidence.json',
    'hosted-adversarial-plan.json', 'nested-package-verification.json',
    'pilot-caller-200e6101-source.zip', 'pilot-target-200e6101-source.zip',
    'preservation-receipt.json', 'provisioning-plan.json', 'validation-receipt.json',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def build(root, output):
    members = {name: (root / name).read_bytes() for name in FILES}
    manifest = {
        'type': 'DISABLED_HOSTED_SYNTHETIC_PILOT_READINESS_NOT_EXECUTION_AUTHORITY',
        'source_sha': '200e6101bf8635453b2186be2f45ec87a5946465',
        'target_build_id': 'b0d29d9f7b362c420b5c56143315ebd1e0cde92d7f00fe4bdff3f46a9836ca1e',
        'member_sha256': {name: digest(data) for name, data in sorted(members.items())},
        'hosted_executed': False, 'zero_cost_guaranteed': False,
        'deployment_authorized': False, 'provider_execution_authorized': False,
        'recovery': 'RECOVERY_BLOCKED', 'custody': 'CREDENTIAL_CUSTODY_BLOCKED',
    }
    members['readiness-manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(set(archive.namelist()))
        for name, expected in manifest['member_sha256'].items():
            assert digest(archive.read(name)) == expected
    print(json.dumps({'file': output.name, 'bytes': output.stat().st_size,
                      'sha256': digest(output.read_bytes()), 'members': len(members)}, sort_keys=True))

if __name__ == '__main__':
    build(Path(__file__).resolve().parent, Path(sys.argv[1]).resolve())
